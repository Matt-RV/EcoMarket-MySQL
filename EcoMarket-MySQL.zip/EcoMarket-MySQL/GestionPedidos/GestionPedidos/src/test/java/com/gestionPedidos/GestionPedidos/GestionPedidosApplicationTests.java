package com.gestionPedidos.GestionPedidos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestionPedidosApplicationTests {

	@Test
	void contextLoads() {
	}

}
